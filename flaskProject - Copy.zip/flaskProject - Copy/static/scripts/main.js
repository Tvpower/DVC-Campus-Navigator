// import data from './canvas_coordinates.js';
// var jsondata = require('../scripts/canvas_coordinates');
// import jsonData from '../scripts/canvas_coordinates';

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

console.log('my data', jsonData);

fetch("./scripts/canvas_coordinates.json")
.then(response => {
   return response.json();
})
.then(jsondata => console.log(jsondata));


const canvas = document.getElementById('DrawCanvas');
const draw = canvas.getContext('2d');
const scale = .22;

draw.linewidth = 10;
draw.strokeStyle = 'red';
draw.beginPath();


// draw.lineTo(502,265);

// Function to travel from Node A to Node B:
// nAx + (oBx - oAx)*scale,  nAy + (oBy - oAy)*scale 

const path = ['HSF', 'e5', 'n6', 'n7', 'n9', 'n10', 'n11', 'n12', 'n13', 'n14', 'n15', 'n16', 'e18', 'LHS'];

// var path;
// readTextFile("../static/path.json", function(text){
//     path = JSON.parse(text); //parse JSON
//     console.log(path);
// });

// var path = pathJsonData["path"]
// it doesnt exist yet
// idk how to read it into pathJsonData from python
draw.moveTo(jsonData[path[0]][0], jsonData[path[0]][1]);
for(let index = 0 ; index < path.length ; index++)
{
    draw.lineTo(jsonData[path[index]][0], jsonData[path[index]][1]);
    draw.moveTo(jsonData[path[index]][0], jsonData[path[index]][1]);
}

draw.closePath();
draw.stroke();